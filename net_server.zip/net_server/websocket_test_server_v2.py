import asyncio
import websockets
import json
import time
import threading
import logging
from typing import Set

# 设置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("WebSocketServer")

class RobotArmWebSocketServer:
    def __init__(self, host="127.0.0.1", port=12000):
        self.host = host
        self.port = port
        self.connected_clients: Set[websockets.WebSocketServerProtocol] = set()
        self.server = None
        self.is_running = False
        
    async def handle_client(self, websocket):
        """处理客户端连接"""
        client_id = id(websocket)
        logger.info(f"客户端 {client_id} 已连接")
        self.connected_clients.add(websocket)
        
        try:
            # 发送欢迎消息
            welcome_msg = {
                "type": "status",
                "value": "connected",
                "timestamp": time.time(),
                "message": "hello"
            }
            await websocket.send(json.dumps(welcome_msg))
            
            # 处理客户端消息
            async for message in websocket:
                await self.process_message(websocket, message)
                
        except websockets.exceptions.ConnectionClosed:
            logger.info(f"客户端 {client_id} 断开连接")
        except Exception as e:
            logger.error(f"处理客户端 {client_id} 时发生错误: {e}")
        finally:
            self.connected_clients.remove(websocket)
            logger.info(f"客户端 {client_id} 已移除")
    
    async def process_message(self, websocket, message):
        """处理接收到的消息"""
        try:
            data = json.loads(message)
            msg_type = data.get("type")
            logger.info(f"收到消息类型: {msg_type}, 内容: {data}")
            
            if msg_type == "status":
                # 处理状态消息
                if data.get("value") == "ready":
                    logger.info("机械臂已就绪，可以发送任务")
                    # 可以在这里发送测试任务
                    await self.send_test_task(websocket)
                    
            elif msg_type == "task_status":
                # 处理任务状态消息
                status = data.get("status")
                if status == "complete":
                    logger.info("任务执行完成")
                    # 等待一段时间后发送新任务
                    await asyncio.sleep(2)
                    await self.send_test_task(websocket)
                    
        except json.JSONDecodeError:
            logger.warning(f"收到非JSON消息: {message}")
        except Exception as e:
            logger.error(f"处理消息时发生错误: {e}")
    
    async def send_test_task(self, websocket):
        """发送测试任务给客户端"""
        task_id = int(time.time())
        task_msg = {
            "type": "task",
            "task_id": task_id,
            "command": "grasp_object",
            "timestamp": time.time(),
            "parameters": {
                "object_type": "blueberry",
                "position": [0.15, -0.25, 0.35],
                "orientation": [0, 0, 0, 1]
            }
        }
        
        try:
            await websocket.send(json.dumps(task_msg))
            logger.info(f"已发送任务 {task_id} 给客户端")
        except Exception as e:
            logger.error(f"发送任务失败: {e}")
    
    async def send_command(self, command_type, **kwargs):
        """向所有客户端发送命令"""
        if not self.connected_clients:
            logger.warning("没有连接的客户端")
            return
            
        message = {
            "type": "command",
            "command": command_type,
            "timestamp": time.time(),
            **kwargs
        }
        
        for client in self.connected_clients:
            try:
                await client.send(json.dumps(message))
                logger.info(f"已发送命令 {command_type} 给客户端")
            except Exception as e:
                logger.error(f"发送命令失败: {e}")
    
    async def start_server(self):
        """启动WebSocket服务器"""
        self.server = await websockets.serve(
            self.handle_client,
            self.host,
            self.port
        )
        self.is_running = True
        logger.info(f"WebSocket服务器已启动在 ws://{self.host}:{self.port}")
        
        # 保持服务器运行
        await self.server.wait_closed()
    
    def stop_server(self):
        """停止服务器"""
        if self.server:
            self.server.close()
            self.is_running = False
            logger.info("服务器已停止")

async def interactive_console(server):
    """交互式控制台，用于手动发送命令"""
    while server.is_running:
        try:
            print("\n=== 机械臂控制台 ===")
            print("1. 发送抓取任务")
            print("2. 发送移动命令")
            print("3. 发送停止命令")
            print("4. 查看连接状态")
            print("5. 退出")
            
            choice = input("请选择操作: ").strip()
            
            if choice == "1":
                await server.send_command("grasp", object_id="obj_001")
            elif choice == "2":
                await server.send_command("move", position=[0.2, -0.3, 0.4])
            elif choice == "3":
                await server.send_command("stop")
            elif choice == "4":
                print(f"当前连接客户端数: {len(server.connected_clients)}")
            elif choice == "5":
                server.stop_server()
                break
            else:
                print("无效选择")
                
            await asyncio.sleep(1)
            
        except Exception as e:
            logger.error(f"控制台错误: {e}")

async def auto_task_generator(server):
    """自动任务生成器，用于测试"""
    task_count = 0
    while server.is_running:
        try:
            if server.connected_clients:
                # 每10秒发送一个任务
                await asyncio.sleep(10)
                task_count += 1
                
                task_msg = {
                    "type": "task",
                    "task_id": task_count,
                    "command": "auto_grasp",
                    "timestamp": time.time(),
                    "parameters": {
                        "task_number": task_count,
                        "target_position": [
                            0.1 + 0.05 * (task_count % 5),
                            -0.2 - 0.05 * (task_count % 3),
                            0.3 + 0.02 * (task_count % 4)
                        ]
                    }
                }
                
                # 发送给所有客户端
                for client in server.connected_clients:
                    try:
                        await client.send(json.dumps(task_msg))
                        logger.info(f"已发送自动任务 {task_count}")
                    except Exception as e:
                        logger.error(f"发送自动任务失败: {e}")
                        
        except Exception as e:
            logger.error(f"自动任务生成器错误: {e}")

async def main():
    """主函数"""
    server = RobotArmWebSocketServer()
    
    try:
        # 启动服务器
        server_task = asyncio.create_task(server.start_server())
        
        # 等待服务器启动
        await asyncio.sleep(1)
        
        # 启动自动任务生成器
        auto_task_task = asyncio.create_task(auto_task_generator(server))
        
        # 启动交互式控制台
        console_task = asyncio.create_task(interactive_console(server))
        
        # 等待所有任务完成
        await asyncio.gather(server_task, auto_task_task, console_task)
        
    except KeyboardInterrupt:
        logger.info("收到中断信号，正在关闭服务器...")
    except Exception as e:
        logger.error(f"服务器运行错误: {e}")
    finally:
        server.stop_server()

def run_server():
    """运行服务器的便捷函数"""
    print("=== 机械臂WebSocket测试服务器 ===")
    print("服务器将运行在: ws://127.0.0.1:12000")
    print("按 Ctrl+C 停止服务器\n")
    
    asyncio.run(main())

# 命令行版本（不需要交互式控制台）
async def simple_server():
    """简单的服务器版本"""
    server = RobotArmWebSocketServer()
    
    print("=== 简单WebSocket测试服务器 ===")
    print("服务器运行中: ws://127.0.0.1:12000")
    print("按 Ctrl+C 停止服务器")
    
    try:
        await server.start_server()
    except KeyboardInterrupt:
        print("\n正在关闭服务器...")
    finally:
        server.stop_server()

if __name__ == "__main__":
    # 安装依赖: pip install websockets
    
    # 运行简单版本
    asyncio.run(simple_server())
    
    # 或者运行完整版本（包含交互控制台）
    # run_server()