import asyncio
import websockets
import json
import time

async def test_websocket_client():
    """测试WebSocket服务器的客户端"""
    uri = "ws://127.0.0.1:12000"
    
    try:
        async with websockets.connect(uri) as websocket:
            print("已连接到WebSocket服务器")
            
            # # 接收欢迎消息
            # welcome_msg = await websocket.recv()
            # print(f"服务器欢迎消息: {welcome_msg}")
            
            while True:
                # 用户输入命令
                command = input("\n请输入命令 (start_grasp/status/quit): ").strip()
                
                if command.lower() == 'quit':
                    print("退出客户端")
                    break
                
                # 发送命令到服务器
                await websocket.send(command)
                print(f"已发送命令: {command}")
                
                # 接收服务器响应
                try:
                    response = await asyncio.wait_for(websocket.recv(), timeout=10.0)
                    if command == "status":
                        # 解析JSON响应
                        status_data = json.loads(response)
                        print("服务器状态:")
                        for key, value in status_data.items():
                            print(f"  {key}: {value}")
                    else:
                        print(f"服务器响应: {response}")
                except asyncio.TimeoutError:
                    print("接收响应超时")
                
    except Exception as e:
        print(f"连接错误: {e}")

async def automated_test():
    """自动化测试函数"""
    uri = "ws://127.0.0.1:12000"
    
    try:
        async with websockets.connect(uri) as websocket:
            print("已连接到WebSocket服务器")
            
            # # 接收欢迎消息
            # welcome_msg = await websocket.recv()
            # print(f"服务器欢迎消息: {welcome_msg}")
            
            # 测试状态查询
            # print("\n=== 测试状态查询 ===")
            # await websocket.send("status")
            # response = await websocket.recv()
            # status_data = json.loads(response)
            # print("服务器状态:", status_data)
            
            # 测试抓取命令
            print("\n=== 测试抓取命令 ===")
            await websocket.send("start_grasp")
            print("已发送抓取命令，等待响应...")
            
            # 等待响应
            start_time = time.time()
            response = await websocket.recv()
            end_time = time.time()
            
            print(f"服务器响应: {response}")
            print(f"响应时间: {end_time - start_time:.2f}秒")
            
    except Exception as e:
        print(f"自动化测试错误: {e}")

if __name__ == "__main__":
    print("WebSocket客户端测试程序")
    print("1. 交互式测试")
    print("2. 自动化测试")
    
    choice = input("请选择测试模式 (1/2): ").strip()
    
    if choice == "2":
        asyncio.run(automated_test())
    else:
        asyncio.run(test_websocket_client())