import threading
import time
import asyncio
import websockets
from websockets.exceptions import ConnectionClosedError
import json

class WebSocketClient:
    def __init__(self, server_uri):
        self.server_uri = server_uri
        self.websocket = None
        self.connected = False
        print(f"WebSocket客户端已创建，目标服务器: {server_uri}")

    async def connect(self):
        try:
            self.websocket = await websockets.connect(self.server_uri)
            self.connected = True
            print("已连接到WebSocket服务器")
            return True
        except Exception as e:
            print(f"连接失败: {e}")
            return False

    async def send_data(self, message):
        if not self.connected or self.websocket is None:
            print("未连接到服务器，无法发送数据")
            return False
            
        try:
            await self.websocket.send(message)
            print(f"消息已发送: {message}")
            return True
        except Exception as e:
            print(f"发送失败: {e}")
            await self.close()
            return False

    async def receive_data(self):
        if not self.connected or self.websocket is None:
            print("未连接到服务器，无法接收数据")
            return None
            
        try:
            data = await self.websocket.recv()
            if data:
                print(f"从服务器接收: {data}")
                return data
            else:
                print("连接已关闭")
                await self.close()
                return None
        except Exception as e:
            print(f"接收失败: {e}")
            await self.close()
            return None

    async def close(self):
        if self.websocket:
            await self.websocket.close()
            self.connected = False
            print("WebSocket连接已关闭")

async def websocket_client_task():
    global _lck, _start_exec, _exec_done
    
    # 连接到本地WebSocket服务器
    client = WebSocketClient("ws://127.0.0.1:12000")
    
    if not await client.connect():
        print("无法连接到WebSocket服务器，websocket_client_task退出")
        return
        
    try:
        # 发送就绪消息
        # await client.send_data("Arm ready")
            
        # 主循环 - 持续监听服务器消息
        while True:
            # 接收数据
            data = await client.receive_data()
            if data is None:
                print("没有收到数据，等待中... (连接可能已断开)")
                break
                
            # 设置执行标志
            with _lck:
                _start_exec = True
                _exec_done = False
                
            print(f"收到任务指令: {data}")
            
            # 模拟处理任务 - 使用sleep代替实际业务逻辑
            print("开始处理任务...")
            time.sleep(2)  # 模拟任务处理时间
            
            # 设置任务完成标志
            with _lck:
                _exec_done = True
                
            print("任务处理完成")
            
            # 发送任务完成消息
            await client.send_data("task complete")
                    
    except Exception as e:
        print(f"websocket_client_task发生异常: {e}")
    finally:
        await client.close()
        print("websocket_client_task退出")

def run_websocket_client():
    asyncio.run(websocket_client_task())

if __name__ == "__main__":  
    # 全局变量
    _lck = threading.Lock()
    _start_exec = False
    _exec_done = False
    
    # 启动WebSocket客户端线程
    t_ws_client = threading.Thread(target=run_websocket_client, args=())
    t_ws_client.daemon = True  # 设置为守护线程，主程序退出时自动结束
    t_ws_client.start()
    
    print("WebSocket客户端已启动，等待服务器消息...")
    print("按Ctrl+C退出程序")
    
    try:
        # 主线程保持运行
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("程序已退出")