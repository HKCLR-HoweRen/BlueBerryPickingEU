#include <boost/beast.hpp>
#include <boost/beast/websocket.hpp>
#include <boost/asio.hpp>
#include <boost/asio/strand.hpp>
#include <boost/json.hpp>
#include <thread>
#include <mutex>
#include <set>
#include <iostream>
#include <memory>

namespace beast = boost::beast;
namespace http = beast::http;
namespace websocket = beast::websocket;
namespace net = boost::asio;
namespace json = boost::json;
using tcp = boost::asio::ip::tcp;

// 全局变量
std::mutex _lck;
bool _start_exec = false;
bool _exec_done = false;
int task_count = 0;

class WebSocketSession : public std::enable_shared_from_this<WebSocketSession> {
public:
    WebSocketSession(websocket::stream<beast::tcp_stream> ws, 
                    std::set<std::shared_ptr<WebSocketSession>>& connected_clients)
        : ws_(std::move(ws)), connected_clients_(connected_clients) {}
    
    void run() {
        // 设置回调
        ws_.set_option(
            websocket::stream_base::timeout::suggested(
                beast::role_type::server));
        
        // 接受WebSocket握手
        ws_.async_accept(
            beast::bind_front_handler(
                &WebSocketSession::on_accept,
                shared_from_this()));
    }
    
    void on_accept(beast::error_code ec) {
        if (ec) {
            std::cerr << "Accept error: " << ec.message() << std::endl;
            return;
        }
        
        client_address_ = ws_.next_layer().socket().remote_endpoint().address().to_string();
        std::cout << "客户端已连接: " << client_address_ << std::endl;
        
        // 添加到连接客户端集合
        connected_clients_.insert(shared_from_this());
        
        // 开始读取消息
        do_read();
    }
    
    void do_read() {
        ws_.async_read(
            buffer_,
            beast::bind_front_handler(
                &WebSocketSession::on_read,
                shared_from_this()));
    }
    
    void on_read(beast::error_code ec, std::size_t bytes_transferred) {
        if (ec == websocket::error::closed) {
            std::cout << "客户端 " << client_address_ << " 断开连接" << std::endl;
            connected_clients_.erase(shared_from_this());
            return;
        }
        
        if (ec) {
            std::cerr << "Read error: " << ec.message() << std::endl;
            return;
        }
        
        // 处理消息
        std::string message = beast::buffers_to_string(buffer_.data());
        std::cout << "收到客户端 " << client_address_ << " 的消息: " << message << std::endl;
        
        if (message == "start_grasp") {
            // 设置执行标志
            {
                std::lock_guard<std::mutex> lock(_lck);
                _start_exec = true;
                _exec_done = false;
            }
            
            // 模拟执行过程
            std::this_thread::sleep_for(std::chrono::seconds(1));
            
            // 设置完成标志
            {
                std::lock_guard<std::mutex> lock(_lck);
                _exec_done = true;
                task_count++;
            }
            
            // 发送任务完成消息
            ws_.async_write(
                net::buffer("task complete"),
                beast::bind_front_handler(
                    &WebSocketSession::on_write,
                    shared_from_this()));
            
            std::cout << "任务完成消息已发送给客户端 " << client_address_ << std::endl;
        } else if (message == "status") {
            // 返回模拟状态
            json::object status;
            status["robot_connected"] = true;
            status["pump_connected"] = true;
            status["camera_connected"] = true;
            status["status"] = "模拟模式";
            
            std::string json_str = json::serialize(status);
            ws_.async_write(
                net::buffer(json_str),
                beast::bind_front_handler(
                    &WebSocketSession::on_write,
                    shared_from_this()));
        } else {
            std::string response = "Unknown command: " + message;
            ws_.async_write(
                net::buffer(response),
                beast::bind_front_handler(
                    &WebSocketSession::on_write,
                    shared_from_this()));
        }
        
        // 清空缓冲区并继续读取
        buffer_.consume(buffer_.size());
        do_read();
    }
    
    void on_write(beast::error_code ec, std::size_t bytes_transferred) {
        if (ec) {
            std::cerr << "Write error: " << ec.message() << std::endl;
            return;
        }
    }
    
private:
    websocket::stream<beast::tcp_stream> ws_;
    beast::flat_buffer buffer_;
    std::string client_address_;
    std::set<std::shared_ptr<WebSocketSession>>& connected_clients_;
};

class WebSocketServer {
public:
    WebSocketServer(net::io_context& ioc, const std::string& host = "0.0.0.0", unsigned short port = 12000)
        : ioc_(ioc), acceptor_(ioc, tcp::endpoint(net::ip::make_address(host), port)) {
        std::cout << "WebSocket服务器已创建，监听地址: " << host << ":" << port << std::endl;
    }
    
    void start() {
        do_accept();
        std::cout << "WebSocket服务器已启动，等待客户端连接..." << std::endl;
        std::cout << "可用命令:" << std::endl;
        std::cout << "- start_grasp: 开始模拟抓取流程" << std::endl;
        std::cout << "- status: 获取服务器状态" << std::endl;
    }
    
    void do_accept() {
        acceptor_.async_accept(
            net::make_strand(ioc_),
            beast::bind_front_handler(
                &WebSocketServer::on_accept,
                this));
    }
    
    void on_accept(beast::error_code ec, tcp::socket socket) {
        if (ec) {
            std::cerr << "Accept error: " << ec.message() << std::endl;
        } else {
            // 创建会话并启动
            auto session = std::make_shared<WebSocketSession>(
                websocket::stream<beast::tcp_stream>(std::move(socket)),
                connected_clients_);
            session->run();
        }
        
        // 继续接受新连接
        do_accept();
    }
    
private:
    net::io_context& ioc_;
    tcp::acceptor acceptor_;
    std::set<std::shared_ptr<WebSocketSession>> connected_clients_;
};

int main() {
    try {
        net::io_context ioc;
        WebSocketServer server(ioc);
        server.start();
        
        // 运行io_context
        ioc.run();
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
        return 1;
    }
    
    return 0;
}