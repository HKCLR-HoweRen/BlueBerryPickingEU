#include <boost/beast.hpp>
#include <boost/beast/websocket.hpp>
#include <boost/asio.hpp>
#include <boost/json.hpp>
#include <iostream>
#include <string>
#include <thread>
#include <chrono>

namespace beast = boost::beast;
namespace http = beast::http;
namespace websocket = beast::websocket;
namespace net = boost::asio;
namespace json = boost::json;
using tcp = boost::asio::ip::tcp;

class WebSocketClient {
public:
    WebSocketClient(net::io_context& ioc) : resolver_(net::make_strand(ioc)), ws_(net::make_strand(ioc)), ioc_(ioc) {}

    void set_test_mode(int mode) { test_mode_ = mode; }

    void run(const std::string& host, const std::string& port) {
        host_ = host;
        port_ = port;

        // 解析地址
        resolver_.async_resolve(
            host,
            port,
            beast::bind_front_handler(
                &WebSocketClient::on_resolve,
                this));
    }

    void on_resolve(beast::error_code ec, tcp::resolver::results_type results) {
        if (ec) {
            std::cerr << "Resolve error: " << ec.message() << std::endl;
            return;
        }

        // 设置超时
        beast::get_lowest_layer(ws_).expires_after(std::chrono::seconds(30));

        // 连接WebSocket
        beast::get_lowest_layer(ws_).async_connect(
            results,
            beast::bind_front_handler(
                &WebSocketClient::on_connect,
                this));
    }

    void on_connect(beast::error_code ec, tcp::resolver::results_type::endpoint_type ep) {
        if (ec) {
            std::cerr << "Connect error: " << ec.message() << std::endl;
            return;
        }

        // 关闭超时设置
        beast::get_lowest_layer(ws_).expires_never();

        // WebSocket设置
        ws_.set_option(websocket::stream_base::timeout::suggested(beast::role_type::client));
        ws_.set_option(websocket::stream_base::decorator(
            [](websocket::request_type& req) {
                req.set(http::field::user_agent, "WebSocketClient");
            }));

        // 执行WebSocket握手
        ws_.async_handshake(
            host_, "/",
            beast::bind_front_handler(
                &WebSocketClient::on_handshake,
                this));
    }

    void on_handshake(beast::error_code ec) {
        if (ec) {
            std::cerr << "Handshake error: " << ec.message() << std::endl;
            return;
        }

        std::cout << "已连接到WebSocket服务器" << std::endl;

        // 根据测试模式选择测试方法
        if (test_mode_ == 2) {
            automated_test();
        } else {
            interactive_test();
        }
    }

    void interactive_test() {
        std::string command;
        while (true) {
            std::cout << "\n请输入命令 (start_grasp/status/quit): ";
            std::getline(std::cin, command);

            if (command == "quit") {
                std::cout << "退出客户端" << std::endl;
                ws_.async_close(websocket::close_code::normal,
                    beast::bind_front_handler(
                        &WebSocketClient::on_close,
                        this));
                break;
            }

            // 发送命令
            ws_.async_write(
                net::buffer(command),
                beast::bind_front_handler(
                    &WebSocketClient::on_write,
                    this));

            // 接收响应
            ws_.async_read(
                buffer_,
                beast::bind_front_handler(
                    &WebSocketClient::on_read,
                    this));

            // 运行io_context以处理异步操作
            ioc_.restart();
            ioc_.run();

            // 清空缓冲区
            buffer_.consume(buffer_.size());
        }
    }

    void automated_test() {
        std::cout << "\n=== 测试抓取命令 ===" << std::endl;

        // 发送抓取命令
        std::string command = "start_grasp";
        ws_.async_write(
            net::buffer(command),
            beast::bind_front_handler(
                &WebSocketClient::on_write,
                this));

        std::cout << "已发送抓取命令，等待响应..." << std::endl;
        auto start_time = std::chrono::steady_clock::now();

        // 接收响应
        ws_.async_read(
            buffer_,
            beast::bind_front_handler(
                &WebSocketClient::on_read_auto,
                this, start_time));

        // 运行io_context以处理异步操作
        ioc_.restart();
        ioc_.run();
    }

    void on_write(beast::error_code ec, std::size_t bytes_transferred) {
        if (ec) {
            std::cerr << "Write error: " << ec.message() << std::endl;
            return;
        }

        std::cout << "已发送命令" << std::endl;
    }

    void on_read(beast::error_code ec, std::size_t bytes_transferred) {
        if (ec) {
            std::cerr << "Read error: " << ec.message() << std::endl;
            return;
        }

        std::string response = beast::buffers_to_string(buffer_.data());
        std::cout << "服务器响应: " << response << std::endl;
    }

    void on_read_auto(std::chrono::steady_clock::time_point start_time,
                     beast::error_code ec, std::size_t bytes_transferred) {
        if (ec) {
            std::cerr << "Read error: " << ec.message() << std::endl;
            return;
        }

        auto end_time = std::chrono::steady_clock::now();
        std::chrono::duration<double> elapsed = end_time - start_time;

        std::string response = beast::buffers_to_string(buffer_.data());
        std::cout << "服务器响应: " << response << std::endl;
        std::cout << "响应时间: " << elapsed.count() << "秒" << std::endl;

        // 关闭连接
        ws_.async_close(websocket::close_code::normal,
            beast::bind_front_handler(
                &WebSocketClient::on_close,
                this));
    }

    void on_close(beast::error_code ec) {
        if (ec) {
            std::cerr << "Close error: " << ec.message() << std::endl;
            return;
        }
    }

private:
    tcp::resolver resolver_;
    websocket::stream<beast::tcp_stream> ws_;
    beast::flat_buffer buffer_;
    std::string host_;
    std::string port_;
    net::io_context& ioc_;
    int test_mode_ = 1; // 默认交互式测试
};

int main() {
    try {
        std::cout << "WebSocket客户端测试程序" << std::endl;
        std::cout << "1. 交互式测试" << std::endl;
        std::cout << "2. 自动化测试" << std::endl;

        int choice;
        std::cout << "请选择测试模式 (1/2): ";
        std::cin >> choice;
        std::cin.ignore(); // 忽略换行符

        net::io_context ioc;
        WebSocketClient client(ioc);
        client.set_test_mode(choice);

        client.run("127.0.0.1", "12000");

        // 运行io_context以处理异步操作
        ioc.run();

    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
        return 1;
    }

    return 0;
}