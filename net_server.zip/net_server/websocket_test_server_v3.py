import threading
import time
import asyncio
import websockets
import json
from websockets.exceptions import ConnectionClosedError

class WebSocketServer:
    def __init__(self, host='0.0.0.0', port=12000):
        self.host = host
        self.port = port
        self.connected_clients = set()
        print(f"WebSocket服务器已创建，监听地址: {host}:{port}")

    async def handler(self, websocket):
        """处理客户端连接"""
        self.connected_clients.add(websocket)
        client_address = websocket.remote_address
        print(f"客户端已连接: {client_address}")
        
        try:
            
            # 监听客户端消息
            async for message in websocket:
                print(f"收到客户端 {client_address} 的消息: {message}")
                
                if message == "start_grasp":
                    # 设置执行标志
                    with _lck:
                        _start_exec = True
                        _exec_done = False
                    
                    # 设置完成标志
                    with _lck:
                        _exec_done = True
                    
                    # 发送任务完成消息
                    await websocket.send("task complete")
                    print(f"任务完成消息已发送给客户端 {client_address}")
                
                else:
                    await websocket.send(f"Unknown command: {message}")
                    
        except ConnectionClosedError:
            print(f"客户端 {client_address} 断开连接")
        finally:
            self.connected_clients.remove(websocket)

    async def start_server(self):
        """启动WebSocket服务器"""
        server = await websockets.serve(self.handler, self.host, self.port)
        print(f"WebSocket服务器已启动，监听在 {self.host}:{self.port}")
        await server.wait_closed()

async def run_websocket_server():
    """运行WebSocket服务器"""
    server = WebSocketServer()
    await server.start_server()

def start_websocket_server():
    """在新线程中启动WebSocket服务器"""
    asyncio.run(run_websocket_server())

if __name__ == "__main__":  
    # 全局变量
    _lck = threading.Lock()
    _start_exec = False
    _exec_done = False
    task_count = 0
    
    # 启动WebSocket服务器线程
    t_ws_server = threading.Thread(target=start_websocket_server, args=())
    t_ws_server.daemon = True  # 设置为守护线程，主程序退出时自动结束
    t_ws_server.start()
    
    print("WebSocket服务器已启动，等待客户端连接...")
    print("可用命令:")
    print("- start_grasp: 开始模拟抓取流程")
    print("- status: 获取服务器状态")
    
    try:
        # 主线程保持运行
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n服务器正在关闭...")